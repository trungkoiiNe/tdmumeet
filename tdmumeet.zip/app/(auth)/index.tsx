import React from 'react';
import OnboardingScreen from './OnboardingScreen'; // Import the new screen

const AuthIndex = () => {
  // Render the OnboardingScreen component
  return <OnboardingScreen />;
};

export default AuthIndex;
